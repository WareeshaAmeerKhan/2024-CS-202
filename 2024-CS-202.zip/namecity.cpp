#include<iostream>
using namespace std;
main()
{
cout<<"Wareesha Ameer Khan"<<endl;
cout<<"Mianwali";
}