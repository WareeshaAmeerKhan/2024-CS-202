#include<iostream>
using namespace std;
main()
{
cout<<"                                ________                      "<<endl;
cout<<"                               //     //                      "<<endl;
cout<<"       _______________________//     //__________             "<<endl;
cout<<"      |                              ||         |            "<<endl;
cout<<"      |                              ||   ___   |_____       "<<endl;
cout<<"     C|                              ||  | o |        \\      "<<endl;
cout<<"      |                              ||  |___|         |> ~~  "<<endl;
cout<<"      |____--_______________--_______||_______--_______|      "<<endl;
cout<<"           00               00                00              "<<endl;
}